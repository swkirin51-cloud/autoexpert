#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram Bot & Mini App Server — «Яндекс.АвтоЭксперт» (Тестовый полигон)
Разработано без сторонних зависимостей (чистая стандартная библиотека Python 3).

Запуск:
    python3 bot.py --token "ВАШ_ТЕЛЕГРАМ_ТОКЕН" --url "https://ваш-https-адрес.домен"
"""

import sys
import os
import json
import math
import time
import socket
import argparse
import threading
import urllib.request
import urllib.parse
from http.server import SimpleHTTPRequestHandler, HTTPServer

PORT = 8080
WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))

class TMAHTTPHandler(SimpleHTTPRequestHandler):
    """Раздача статики WebApp с корректными заголовками и CORS"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WORKSPACE_DIR, **kwargs)

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def log_message(self, format, *args):
        # Тихий лог чтобы не засорять консоль
        pass

def run_http_server(port=PORT):
    server_address = ('0.0.0.0', port)
    try:
        httpd = HTTPServer(server_address, TMAHTTPHandler)
        print(f"[HTTP] Сервер Mini App запущен: http://localhost:{port}/")
        httpd.serve_forever()
    except Exception as e:
        print(f"[HTTP] Ошибка запуска сервера: {e}")

# ================= Telegram Bot API (urllib) =================

class TelegramBot:
    def __init__(self, token, webapp_url=None):
        self.token = token
        self.webapp_url = webapp_url or f"http://localhost:{PORT}/"
        self.api_url = f"https://api.telegram.org/bot{token}"
        self.last_update_id = 0

    def make_request(self, method, payload=None):
        url = f"{self.api_url}/{method}"
        headers = {"Content-Type": "application/json"}
        data = json.dumps(payload).encode("utf-8") if payload else None
        req = urllib.request.Request(url, data=data, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"ok": False, "description": str(e)}

    def send_message(self, chat_id, text, reply_markup=None):
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self.make_request("sendMessage", payload)

    def handle_command(self, chat_id, text, web_app_data=None):
        if web_app_data:
            # Получены данные из Mini App
            try:
                data = json.loads(web_app_data)
                resp = (
                    "📋 *ЭКСПЕРТНОЕ ЗАКЛЮЧЕНИЕ (ПОЛИГОН АВТОЭКСПЕРТ)*\n\n"
                    f"🔹 *Событие:* {data.get('type', 'ДТП')}\n"
                    f"🔹 *Транспорт:* {data.get('vehicle', 'Автомобиль')} (kt = {data.get('kt', 1.0)})\n"
                    f"🔹 *Покрытие:* {data.get('road', 'Сухой асфальт')} (kc = {data.get('kc', 0.7)})\n"
                    f"🔹 *Длина юза:* {data.get('distance', 0)} м\n"
                    f"🔹 *Расчетная скорость V₀:* *{data.get('speed', 0)} км/ч*\n"
                    f"🔹 *Установленный лимит:* {data.get('limit', 60)} км/ч\n\n"
                    f"⚖️ *Квалификация:* {data.get('verdict', 'Анализ завершен')}\n"
                    f"📌 *Формула Минюста:* `V = √(S · kc · 254 / kt)`\n\n"
                    "_Данные зафиксированы для формирования судебного ходатайства._"
                )
                self.send_message(chat_id, resp)
            except Exception as ex:
                self.send_message(chat_id, f"⚠️ Ошибка обработки данных экспертизы: {ex}")
            return

        cmd = text.split()[0].lower() if text else ""
        args = text.split()[1:] if text else []

        if cmd == "/start":
            is_https = self.webapp_url.startswith("https://")
            keyboard = {
                "inline_keyboard": [
                    [
                        {
                            "text": "🚀 Открыть полигон «Яндекс.АвтоЭксперт»",
                            "web_app": {"url": self.webapp_url}
                        } if is_https else {
                            "text": "🌐 Открыть полигон (браузер)",
                            "url": self.webapp_url
                        }
                    ],
                    [
                        {"text": "⚖️ Методика ЭКЦ МВД", "callback_data": "cmd_mvd"},
                        {"text": "🛡️ Трасология СОДФУ", "callback_data": "cmd_sodfu"}
                    ],
                    [
                        {"text": "⚡ Экспресс-расчет", "callback_data": "cmd_calc_help"}
                    ]
                ]
            }
            welcome = (
                "👋 *Добро пожаловать в тестовый полигон «Яндекс.АвтоЭксперт»!*\n\n"
                "Этот бот и Mini App созданы для проверки формул автотехнической экспертизы, "
                "судебной практики по ст. 264 УК РФ и споров со страховыми компаниями.\n\n"
                f"🔗 *URL полигона:* `{self.webapp_url}`\n\n"
                "📌 *Команды:*\n"
                "• `/calc <метры> [асфальт/мокрый/снег/лед]` — экспресс-расчет в чате\n"
                "• `/mvd` — методика ЭКЦ МВД (ст. 264 УК РФ, остановочный путь $S_0$ vs удаление $S_a$)\n"
                "• `/sodfu` — методика АНО «СОДФУ» (динамический клевок подвески, трасология)\n"
                "• `/link` — получить актуальную ссылку на полигон"
            )
            self.send_message(chat_id, welcome, reply_markup=keyboard)

        elif cmd == "/calc":
            if not args:
                self.send_message(chat_id, "💡 Формат команды: `/calc <длина_торможения_м> [тип_покрытия]`\nПример: `/calc 25 мокрый`")
                return
            try:
                s = float(args[0])
                kc = 0.7 # по умолчанию сухой
                road = "Сухой асфальт"
                if len(args) > 1:
                    r = args[1].lower()
                    if "мокр" in r:
                        kc = 0.4
                        road = "Мокрый асфальт"
                    elif "снег" in r:
                        kc = 0.2
                        road = "Укатанный снег"
                    elif "лед" in r or "гололед" in r:
                        kc = 0.1
                        road = "Обледенение"
                v = math.sqrt(s * kc * 254 / 1.0)
                v_round = round(v, 1)
                limit = 60
                delta = round(v_round - limit, 1)
                verdict = f"⚠️ *Превышение на {delta} км/ч* (п. 10.1, 10.2 ПДД)" if delta > 0 else "✅ *Скорость в пределах нормы* (до 60 км/ч)"
                msg = (
                    f"🏎️ *Экспресс-расчет скорости по следу торможения:*\n\n"
                    f"• Длина юза: *{s} м*\n"
                    f"• Покрытие: *{road}* (kc = {kc})\n"
                    f"• Тип ТС: *Легковой* (kt = 1.0)\n\n"
                    f"📊 *Начальная скорость: {v_round} км/ч*\n"
                    f"{verdict}\n\n"
                    f"`Формула: V = √({s} · {kc} · 254 / 1.0) = {v_round} км/ч`"
                )
                self.send_message(chat_id, msg)
            except ValueError:
                self.send_message(chat_id, "⚠️ Ошибка: укажите корректное число метров (например, `/calc 28.5`).")

        elif cmd == "/mvd":
            msg = (
                "⚖️ *МЕТОДИКА ЭКЦ МВД (2010 г.) — ст. 264 УК РФ*\n\n"
                "Ключевой вопрос следователя и суда: _«Располагал ли водитель технической возможностью предотвратить наезд?»_\n\n"
                "1. *Остановочный путь S₀:* автомобиль начинает тормозить не мгновенно!\n"
                "`S₀ = (t₁ + t₂ + 0.5·t₃) · (Va / 3.6) + Va² / (26 · ja)`\n"
                "• `t₁` = время реакции водителя (0.6–1.4 с)\n"
                "• `t₂` = время срабатывания привода (0.1–0.4 с)\n"
                "• `t₃` = нарастание замедления (0.2–0.5 с)\n"
                "• `ja` = установившееся замедление (6.8–7.5 м/с² на сухом)\n\n"
                "2. *Удаление пешехода Sa:* расстояние от машины до пешехода в момент возникновения опасности.\n"
                "• Если `S₀ ≤ Sa` — водитель *располагал* технической возможностью (виновен по п. 10.1 ПДД).\n"
                "• Если `S₀ > Sa` — водитель *НЕ располагал* возможностью (невиновен, отсутствует состав преступления)."
            )
            self.send_message(chat_id, msg)

        elif cmd == "/sodfu":
            msg = (
                "🛡️ *МЕТОДИКА АНО «СОДФУ» (Звягин, 2021) — СПОРЫ СО СТРАХОВЫМИ*\n\n"
                "Страховые компании часто отказывают в выплатах по ОСАГО/КАСКО под предлогом: _«Повреждения не соответствуют обстоятельствам ДТП, бамперы не совпадают по высоте»_.\n\n"
                "🔍 *Главный козырь защиты — динамический клевок кузова:*\n"
                "• При экстренном торможении передняя ось проседает на *30–70 мм*, а задняя поднимается на *20–45 мм*.\n"
                "• Эксперты страховщиков сопоставляют стоящие авто в статике, занижая зону контакта!\n"
                "• Трасологический анализ по Звягину доказывает образование пар контактирования именно в фазе динамического торможения."
            )
            self.send_message(chat_id, msg)

        elif cmd == "/link":
            self.send_message(chat_id, f"🔗 Ссылка на полигон: `{self.webapp_url}`")

    def poll(self):
        print(f"[BOT] Запущен Telegram Bot Polling (токен: {self.token[:6]}...{self.token[-4:]})")
        print(f"[BOT] WebApp URL: {self.webapp_url}")
        while True:
            try:
                res = self.make_request("getUpdates", {"offset": self.last_update_id + 1, "timeout": 20})
                if res.get("ok"):
                    for update in res.get("result", []):
                        self.last_update_id = update["update_id"]
                        msg = update.get("message", {})
                        chat = msg.get("chat", {})
                        chat_id = chat.get("id")
                        text = msg.get("text", "")
                        web_app_data = msg.get("web_app_data", {}).get("data")
                        if chat_id:
                            self.handle_command(chat_id, text, web_app_data)
                time.sleep(0.5)
            except Exception as e:
                print(f"[BOT] Ошибка polling: {e}")
                time.sleep(3)


def main():
    parser = argparse.ArgumentParser(description="АвтоЭксперт — Telegram Bot & Mini App Server")
    parser.add_argument("--token", type=str, default=os.environ.get("TG_BOT_TOKEN", ""), help="Telegram Bot Token от @BotFather")
    parser.add_argument("--url", type=str, default="", help="Внешний HTTPS URL для Telegram WebApp")
    parser.add_argument("--port", type=int, default=PORT, help=f"Порт локального HTTP-сервера (по умолчанию {PORT})")
    args = parser.parse_args()

    # 1. Запуск фонового веб-сервера
    http_thread = threading.Thread(target=run_http_server, args=(args.port,), daemon=True)
    http_thread.start()

    # 2. Если токен не передан — инструкция
    if not args.token:
        print("\n" + "="*70)
        print("⚡ ТЕСТОВЫЙ ПОЛИГОН «ЯНДЕКС.АВТОЭКСПЕРТ»")
        print("="*70)
        print(f" Локальный веб-интерфейс запущен: http://localhost:{args.port}/index.html")
        print(" Для подключения к Telegram боту запустите скрипт с токеном:")
        print(f' python3 bot.py --token "ВАШ_ТОКЕН_ОТ_BOTFATHER" --url "ВАШ_HTTPS_URL"')
        print("="*70 + "\n")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nОстановка сервера...")
            sys.exit(0)

    # 3. Запуск бота
    url = args.url if args.url else f"http://localhost:{args.port}/index.html"
    bot = TelegramBot(token=args.token, webapp_url=url)
    bot.poll()

if __name__ == "__main__":
    main()
